/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        ink: "#111827",
        radio: "#e11d48",
        signal: "#06b6d4",
        cream: "#f8fafc",
      },
      boxShadow: {
        panel: "0 18px 50px -30px rgba(15,23,42,.38)",
      },
    },
  },
  plugins: [],
};
